// ExeToInjectInTo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	printf("Press enter to close.\n");
	getchar();
	
	return 0;
}

